hw6.py created by Satoshi Matsuura(matsus2) and Parshva Shah(shahp2)
directory is gone through with windows. 
ran using python hw6.py [filename]